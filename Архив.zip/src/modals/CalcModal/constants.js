export const termOptions = [
    { value: 12, label: '12' },
    { value: 24, label: '24' },
    { value: 36, label: '36' },
    { value: 48, label: '48' },
];

export const paymentPeriodOptions = [
    { value: 'yearly', label: 'В год' },
    { value: 'monthly', label: 'В месяц' },
];
